package co.grupo7.ciclo4.proyectoCiclo4_grupo7.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.grupo7.ciclo4.proyectoCiclo4_grupo7.models.ProductoModel;
import co.grupo7.ciclo4.proyectoCiclo4_grupo7.repositories.ProductoRepository;

@Service
public class ProductoService {

    @Autowired
    ProductoRepository productoRepository;

    public ArrayList<ProductoModel> obtenerProductos(){
        return (ArrayList<ProductoModel>) productoRepository.findAll();
    }

    public ProductoModel guardarProducto(ProductoModel producto){
        producto.setNombre(producto.getNombre().toLowerCase());
        producto.setColor(producto.getColor().toLowerCase());
        return productoRepository.save(producto);
    }

    public Boolean eliminarProductoPorID(String id){

        if(productoRepository.existsById(id)){

            productoRepository.deleteById(id);

            return true;

        }
        else{

            return false;

        }

    }

    public Optional<ProductoModel> obtenerProductoPorID(String id){

        return productoRepository.findById(id);
        
    }

    public ArrayList<ProductoModel> obtenerProductoPorNombre(String nombre){

        return productoRepository.findByNombre(nombre.toLowerCase());

    }

    public ArrayList<ProductoModel> obtenerProductoPorColor(String color){

        return productoRepository.findByColor(color.toLowerCase());

    }
    
    public ArrayList<ProductoModel> obtenerProductoPorFecha(LocalDate fechaRegistro){

        return productoRepository.findByFechaRegistro(fechaRegistro);

    }
}
