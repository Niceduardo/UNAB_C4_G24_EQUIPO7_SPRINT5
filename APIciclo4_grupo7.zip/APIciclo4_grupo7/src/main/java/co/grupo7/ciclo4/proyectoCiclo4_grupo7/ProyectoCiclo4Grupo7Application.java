package co.grupo7.ciclo4.proyectoCiclo4_grupo7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCiclo4Grupo7Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCiclo4Grupo7Application.class, args);
	}

}
